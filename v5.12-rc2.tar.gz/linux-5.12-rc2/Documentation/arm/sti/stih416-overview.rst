================
STiH416 Overview
================

Introduction
------------

    The STiH416 is the next generation of HD, AVC set-top box processors
    for satellite, cable, terrestrial and IP-STB markets.

    Features
    - ARM Cortex-A9 1.2 GHz dual core CPU
    - SATA2x2,USB 2.0x3, PCIe, Gbit Ethernet MACx2
