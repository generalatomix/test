.. SPDX-License-Identifier: GPL-2.0

==========================
Samsung S3C24XX SoC Family
==========================

.. toctree::
   :maxdepth: 1

   h1940
   gpio
   cpufreq
   suspend
   usb-host
   s3c2412
   eb2410itx
   nand
   smdk2440
   s3c2413
   overview
