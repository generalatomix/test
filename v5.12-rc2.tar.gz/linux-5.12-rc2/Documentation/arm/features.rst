.. SPDX-License-Identifier: GPL-2.0

.. kernel-feat:: $srctree/Documentation/features arm
