.. SPDX-License-Identifier: GPL-2.0

===================================
NetWinder's floating point emulator
===================================

.. toctree::
   :maxdepth: 1

   nwfpe
   netwinder-fpe
   notes
   todo
