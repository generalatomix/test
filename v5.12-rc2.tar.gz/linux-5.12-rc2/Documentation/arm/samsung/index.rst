.. SPDX-License-Identifier: GPL-2.0

===========
Samsung SoC
===========

.. toctree::
   :maxdepth: 1

   gpio
   bootloader-interface
   overview
