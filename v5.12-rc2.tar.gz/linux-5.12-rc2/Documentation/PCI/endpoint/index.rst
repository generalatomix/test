.. SPDX-License-Identifier: GPL-2.0

======================
PCI Endpoint Framework
======================

.. toctree::
   :maxdepth: 2

   pci-endpoint
   pci-endpoint-cfs
   pci-test-function
   pci-test-howto
   pci-ntb-function
   pci-ntb-howto

   function/binding/pci-test
   function/binding/pci-ntb
