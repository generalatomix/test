ABI removed symbols
===================

.. kernel-abi:: $srctree/Documentation/ABI/removed
   :rst:
