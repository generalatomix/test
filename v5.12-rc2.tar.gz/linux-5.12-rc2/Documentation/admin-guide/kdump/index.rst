
================================================================
Documentation for Kdump - The kexec-based Crash Dumping Solution
================================================================

This document includes overview, setup and installation, and analysis
information.

.. toctree::
    :maxdepth: 1

    kdump
    vmcoreinfo

.. only::  subproject and html

   Indices
   =======

   * :ref:`genindex`
