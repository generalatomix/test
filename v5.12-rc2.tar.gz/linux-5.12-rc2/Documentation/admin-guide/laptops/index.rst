.. SPDX-License-Identifier: GPL-2.0

==============
Laptop Drivers
==============

.. toctree::
   :maxdepth: 1

   asus-laptop
   disk-shock-protection
   laptop-mode
   lg-laptop
   sony-laptop
   sonypi
   thinkpad-acpi
   toshiba_haps
