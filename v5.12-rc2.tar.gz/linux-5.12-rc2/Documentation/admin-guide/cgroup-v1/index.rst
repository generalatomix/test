.. _cgroup-v1:

========================
Control Groups version 1
========================

.. toctree::
    :maxdepth: 1

    cgroups

    blkio-controller
    cpuacct
    cpusets
    devices
    freezer-subsystem
    hugetlb
    memcg_test
    memory
    net_cls
    net_prio
    pids
    rdma

.. only::  subproject and html

   Indices
   =======

   * :ref:`genindex`
