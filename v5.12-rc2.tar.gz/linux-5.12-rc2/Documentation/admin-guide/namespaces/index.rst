.. SPDX-License-Identifier: GPL-2.0

==========
Namespaces
==========

.. toctree::
   :maxdepth: 1

   compatibility-list
   resource-control
