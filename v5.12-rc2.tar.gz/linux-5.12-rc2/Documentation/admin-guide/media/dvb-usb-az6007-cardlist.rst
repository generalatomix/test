.. SPDX-License-Identifier: GPL-2.0

dvb-usb-az6007 cards list
=========================

.. tabularcolumns:: |p{7.0cm}|p{10.5cm}|

.. flat-table::
   :header-rows: 1
   :widths: 7 13
   :stub-columns: 0

   * - Card name
     - USB IDs
   * - Azurewave 6007
     - 13d3:0ccd
   * - Technisat CableStar Combo HD CI
     - 14f7:0003
   * - Terratec H7
     - 0ccd:10b4, 0ccd:10a3
