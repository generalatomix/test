.. SPDX-License-Identifier: GPL-2.0

CX18 cards list
===============

Those cards are supported by cx18 driver:

- Hauppauge HVR-1600 (ESMT memory)
- Hauppauge HVR-1600 (Samsung memory)
- Compro VideoMate H900
- Yuan MPC718 MiniPCI DVB-T/Analog
- Conexant Raptor PAL/SECAM
- Toshiba Qosmio DVB-T/Analog
- Leadtek WinFast PVR2100
- Leadtek WinFast DVR3100
- GoTView PCI DVD3 Hybrid
- Hauppauge HVR-1600 (s5h1411/tda18271)
