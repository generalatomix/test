.. SPDX-License-Identifier: GPL-2.0

AU0828 cards list
=================

.. tabularcolumns:: |p{1.4cm}|p{6.5cm}|p{10.0cm}|

.. flat-table::
   :header-rows: 1
   :widths: 2 19 18
   :stub-columns: 0

   * - Card number
     - Card name
     - USB IDs

   * - 0
     - Unknown board
     -

   * - 1
     - Hauppauge HVR950Q
     - 2040:7200, 2040:7210, 2040:7217, 2040:721b, 2040:721e, 2040:721f, 2040:7280, 0fd9:0008, 2040:7260, 2040:7213, 2040:7270

   * - 2
     - Hauppauge HVR850
     - 2040:7240

   * - 3
     - DViCO FusionHDTV USB
     - 0fe9:d620

   * - 4
     - Hauppauge HVR950Q rev xxF8
     - 2040:7201, 2040:7211, 2040:7281

   * - 5
     - Hauppauge Woodbury
     - 05e1:0480, 2040:8200
