.. SPDX-License-Identifier: GPL-2.0

dvb-usb-gl861 cards list
========================

.. tabularcolumns:: |p{7.0cm}|p{10.5cm}|

.. flat-table::
   :header-rows: 1
   :widths: 7 13
   :stub-columns: 0

   * - Card name
     - USB IDs
   * - 774 Friio White ISDB-T USB2.0
     - 7a69:0001
   * - A-LINK DTU DVB-T USB2.0
     - 05e3:f170
   * - MSI Mega Sky 55801 DVB-T USB2.0
     - 0db0:5581
