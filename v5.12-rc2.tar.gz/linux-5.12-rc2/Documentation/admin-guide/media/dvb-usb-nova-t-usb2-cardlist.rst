.. SPDX-License-Identifier: GPL-2.0

dvb-usb-nova-t-usb2 cards list
==============================

.. tabularcolumns:: |p{7.0cm}|p{10.5cm}|

.. flat-table::
   :header-rows: 1
   :widths: 7 13
   :stub-columns: 0

   * - Card name
     - USB IDs
   * - Hauppauge WinTV-NOVA-T usb2
     - 2040:9300, 2040:9301
