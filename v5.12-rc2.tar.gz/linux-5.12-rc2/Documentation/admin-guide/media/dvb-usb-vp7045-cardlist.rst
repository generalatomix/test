.. SPDX-License-Identifier: GPL-2.0

dvb-usb-vp7045 cards list
=========================

.. tabularcolumns:: |p{7.0cm}|p{10.5cm}|

.. flat-table::
   :header-rows: 1
   :widths: 7 13
   :stub-columns: 0

   * - Card name
     - USB IDs
   * - DigitalNow TinyUSB 2 DVB-t Receiver
     - 13d3:3223, 13d3:3224
   * - Twinhan USB2.0 DVB-T receiver (TwinhanDTV Alpha/MagicBox II)
     - 13d3:3205, 13d3:3206
