.. SPDX-License-Identifier: GPL-2.0

dvb-usb-pctv452e cards list
===========================

.. tabularcolumns:: |p{7.0cm}|p{10.5cm}|

.. flat-table::
   :header-rows: 1
   :widths: 7 13
   :stub-columns: 0

   * - Card name
     - USB IDs
   * - PCTV HDTV USB
     - 2304:021f
   * - Technotrend TT Connect S2-3600
     - 0b48:3007
   * - Technotrend TT Connect S2-3650-CI
     - 0b48:300a
