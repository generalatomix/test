.. SPDX-License-Identifier: GPL-2.0

dvb-usb-az6027 cards list
=========================

.. tabularcolumns:: |p{7.0cm}|p{10.5cm}|

.. flat-table::
   :header-rows: 1
   :widths: 7 13
   :stub-columns: 0

   * - Card name
     - USB IDs
   * - AZUREWAVE DVB-S/S2 USB2.0 (AZ6027)
     - 13d3:3275
   * - Elgato EyeTV Sat
     - 0fd9:002a, 0fd9:0025, 0fd9:0036
   * - TERRATEC S7
     - 0ccd:10a4
   * - TERRATEC S7 MKII
     - 0ccd:10ac
   * - Technisat SkyStar USB 2 HD CI
     - 14f7:0001, 14f7:0002
