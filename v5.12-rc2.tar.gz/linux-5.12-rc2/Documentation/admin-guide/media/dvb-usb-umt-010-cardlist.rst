.. SPDX-License-Identifier: GPL-2.0

dvb-usb-umt-010 cards list
==========================

.. tabularcolumns:: |p{7.0cm}|p{10.5cm}|

.. flat-table::
   :header-rows: 1
   :widths: 7 13
   :stub-columns: 0

   * - Card name
     - USB IDs
   * - Hanftek UMT-010 DVB-T USB2.0
     - 15f4:0001, 15f4:0015
