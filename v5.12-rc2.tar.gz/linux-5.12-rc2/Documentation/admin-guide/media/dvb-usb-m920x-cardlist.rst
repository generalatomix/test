.. SPDX-License-Identifier: GPL-2.0

dvb-usb-m920x cards list
========================

.. tabularcolumns:: |p{7.0cm}|p{10.5cm}|

.. flat-table::
   :header-rows: 1
   :widths: 7 13
   :stub-columns: 0

   * - Card name
     - USB IDs
   * - DTV-DVB UDTT7049
     - 13d3:3219
   * - Dposh DVB-T USB2.0
     - 1498:9206, 1498:a090
   * - LifeView TV Walker Twin DVB-T USB2.0
     - 10fd:0514, 10fd:0513
   * - MSI DIGI VOX mini II DVB-T USB2.0
     - 10fd:1513
   * - MSI Mega Sky 580 DVB-T USB2.0
     - 0db0:5580
   * - Pinnacle PCTV 310e
     - 13d3:3211
