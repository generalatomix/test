.. SPDX-License-Identifier: GPL-2.0

dvb-usb-gp8psk cards list
=========================

.. tabularcolumns:: |p{7.0cm}|p{10.5cm}|

.. flat-table::
   :header-rows: 1
   :widths: 7 13
   :stub-columns: 0

   * - Card name
     - USB IDs
   * - Genpix 8PSK-to-USB2 Rev.1 DVB-S receiver
     - 09c0:0200, 09c0:0201
   * - Genpix 8PSK-to-USB2 Rev.2 DVB-S receiver
     - 09c0:0202
   * - Genpix SkyWalker-1 DVB-S receiver
     - 09c0:0203
   * - Genpix SkyWalker-2 DVB-S receiver
     - 09c0:0206
