.. SPDX-License-Identifier: GPL-2.0

dvb-usb-vp702x cards list
=========================

.. tabularcolumns:: |p{7.0cm}|p{10.5cm}|

.. flat-table::
   :header-rows: 1
   :widths: 7 13
   :stub-columns: 0

   * - Card name
     - USB IDs
   * - TwinhanDTV StarBox DVB-S USB2.0 (VP7021)
     - 13d3:3207
