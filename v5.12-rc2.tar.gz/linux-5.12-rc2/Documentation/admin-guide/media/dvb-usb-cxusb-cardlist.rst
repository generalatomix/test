.. SPDX-License-Identifier: GPL-2.0

dvb-usb-cxusb cards list
========================

.. tabularcolumns:: |p{7.0cm}|p{10.5cm}|

.. flat-table::
   :header-rows: 1
   :widths: 7 13
   :stub-columns: 0

   * - Card name
     - USB IDs
   * - AVerMedia AVerTVHD Volar (A868R)
     -
   * - Conexant DMB-TH Stick
     -
   * - DViCO FusionHDTV DVB-T Dual Digital 2
     -
   * - DViCO FusionHDTV DVB-T Dual Digital 4
     -
   * - DViCO FusionHDTV DVB-T Dual Digital 4 (rev 2)
     -
   * - DViCO FusionHDTV DVB-T Dual USB
     -
   * - DViCO FusionHDTV DVB-T NANO2
     -
   * - DViCO FusionHDTV DVB-T USB (LGZ201)
     -
   * - DViCO FusionHDTV DVB-T USB (TH7579)
     -
   * - DViCO FusionHDTV5 USB Gold
     -
   * - DigitalNow DVB-T Dual USB
     -
   * - Medion MD95700 (MDUSBTV-HYBRID)
     -
   * - Mygica D689 DMB-TH
     -
