.. SPDX-License-Identifier: GPL-2.0

dvb-usb-lmedm04 cards list
==========================

.. tabularcolumns:: |p{7.0cm}|p{10.5cm}|

.. flat-table::
   :header-rows: 1
   :widths: 7 13
   :stub-columns: 0

   * - Card name
     - USB IDs
   * - DM04_LME2510C_DVB-S
     - 3344:1120
   * - DM04_LME2510C_DVB-S RS2000
     - 3344:22f0
   * - DM04_LME2510_DVB-S
     - 3344:1122
