.. SPDX-License-Identifier: GPL-2.0

==============================
Working-State Power Management
==============================

.. toctree::
   :maxdepth: 2

   cpuidle
   intel_idle
   cpufreq
   intel_pstate
   cpufreq_drivers
   intel_epb
   intel-speed-select
