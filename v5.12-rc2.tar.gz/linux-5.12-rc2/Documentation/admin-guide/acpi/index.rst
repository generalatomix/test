============
ACPI Support
============

Here we document in detail how to interact with various mechanisms in
the Linux ACPI support.

.. toctree::
   :maxdepth: 1

   initrd_table_override
   dsdt-override
   ssdt-overlays
   cppc_sysfs
   fan_performance_states
