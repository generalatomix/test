.. SPDX-License-Identifier: GPL-2.0

====
gpio
====

.. toctree::
    :maxdepth: 1

    gpio-aggregator
    sysfs
    gpio-mockup

.. only::  subproject and html

   Indices
   =======

   * :ref:`genindex`
